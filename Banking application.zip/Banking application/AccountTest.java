import java.util.Scanner;
import java.util.Arrays;
import java.io.File;
import java.io.FileInputStream;
import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class AccountTest
{
    private static Scanner input ;
    private static String fileName;
	private static AVLTree avlt = new AVLTree();
	private static Account act = new Account();


	public static void main(String args[])
	{
		
		fileName = args[0];
		openFile();
		readRecords();
		closeFile();

		float balance =  0 ;
        
        
        Scanner input = new Scanner(System.in);
        System.out.println("press any key or -1 to exit");
        int i = input.nextInt();

        while (i !=-1)  
        {
            System.out.println("\nAVLTree Operations\n");
            System.out.println("1. insert ");
            System.out.println("2. search");
            System.out.println("3 . delete");
            System.out.println("4 . print");
            

 
            int choice = input.nextInt();            
            switch (choice)
            {
                case 1 : 
                    System.out.print("Enter Name: ");
					String name  = input.next();
					System.out.print("Enter id: ");
					int iD = input.nextInt();
					System.out.print("Enter Balance: ");
					balance = input.nextFloat();
					avlt.insert(new Account(iD,name,balance));
                    act.setBalance(balance);
                break;

                case 2 : 
                    System.out.println("Enter account iD to search");
                    int n = input.nextInt();
                    System.out.println("Search result : "+ avlt.search(n));
                break;

                 case 3:
                 System.out.println("enter account id to delete");
                int b = input.nextInt();
                System.out.println("the node with id " +b+ " deleted");
                	avlt.remove(b);
                	act.totalAfterDelete(act.balance);
                break;

                case 4 :
                    System.out.println("Total deposit in bank  = Rs " +act.getTotal());
                	System.out.println("number of account holders = " + avlt.countNodes() );
                    avlt.inorder();
                break;

               
            }
            System.out.println("\npress any key or -1 to exit\n");
            i = input.nextInt();
        }
    }
	public static void openFile()
	{
		try
		{
			input = new Scanner(Paths.get(fileName));
		}
		catch(IOException e )
		{
			System.out.println("no such file found");
			System.exit(1);
		}
	}
	public static void readRecords()
	{	
		String name ;
		int id ;
		float balance;
		try
		{
			while(true)
			{
				 name = input.next();
				 id = input.nextInt();
				 balance = input.nextFloat();
				 avlt.insert(new Account(id,name,balance));
				 act.setBalance(balance);
			}
		}
		catch(NoSuchElementException e )
		{
			//System.err.println("file imporoperly formed");
		}
		
		
	}		
	public static void closeFile()
	{
		if(input!=null)
		{
			
		 input.close();
		}
	}	
}
class AVLNode
{    
    AVLNode left, right;
    Account data;
    int height;

    AVLNode element;

    public AVLNode()
    {
        left = null;
        right = null;
        height = 0;
    }
    public AVLNode(Account n)
    {
        left = null;
        right = null;
        data = n;
        height = 0;
    }     
}

class AVLTree
{
    private AVLNode root;    
    public AVLTree()
    {
        root = null;
    }
    public boolean isEmpty()
    {
        return root == null;
    }
    public void makeEmpty()
    {
        root = null;
    }
    public void insert(Account data)
    {
        root = insert(data, root);
    }
    private int height(AVLNode t )
    {
        return t == null ? -1 : t.height;
    }
    private int max(int lhs, int rhs)
    {
        return lhs > rhs ? lhs : rhs;
    }
    private AVLNode insert(Account x, AVLNode t)
    {
        if (t == null)
            t = new AVLNode(x);
        else 
			if (x.compareTo(t.data ) < 0)
			{
				t.left = insert( x, t.left );
				if( height( t.left ) - height( t.right ) == 2 )
					if( x.compareTo(t.left.data) < 0 )
						t = rotateWithLeftChild( t );
					else
						t = doubleWithLeftChild( t );
			}
			else 
				if( x.compareTo( t.data) > 0 )
				{
					t.right = insert( x, t.right );
		                if( x.compareTo(t.right.data) > 0)
                             t = rotateWithRightChild( t );
                        else
            			 if( height( t.right ) - height( t.left ) == 2 )
						 	t = doubleWithRightChild( t );
				}
				else
				    t.height = max( height( t.left ), height( t.right ) ) + 1;
         
      return t;
    }
    
    public AVLNode findMin( )
    {
      	if( isEmpty( ) )
      	{
         System.out.println("Tree is empty");
        } 

       return findMin( root ).element;
   	}
    private AVLNode findMin( AVLNode t )
    {
        if( t == null )
            return t;

        while( t.left != null )
            t = t.left;
        return t;
    }
    public AVLNode findMax( )
    {
        if( isEmpty( ) )
           System.out.println("Tree is empty");

        return findMax( root ).element;
    }
    private AVLNode findMax( AVLNode t )
    {
        if( t == null )
            return t;

        while( t.right != null )
            t = t.right;
        return t;
    }
       
    public void remove(int x )
    {
        root = remove( x, root );
    }
    private AVLNode remove( int  x, AVLNode t )
    {
        if( t == null )
            return t;   
            
        int compareResult = ((Integer)x).compareTo( t.data.getiD());
            
        if( compareResult < 0 )
            t.left = remove( x, t.left );
        else if( compareResult > 0 )
            t.right = remove( x, t.right );
        else if( t.left != null && t.right != null ) 
        {
            t.data = findMin( t.right ).data;
            t.right = remove( x, t.right );
        }
        else
            t = ( t.left != null ) ? t.left : t.right;
        return balance( t );
        
    
    }
    private static final int ALLOWED_IMBALANCE = 1;
    private AVLNode balance( AVLNode t )
    {
        if( t == null )
            return t;
        
        if( height( t.left ) - height( t.right ) > ALLOWED_IMBALANCE )
            if( height( t.left.left ) >= height( t.left.right ) )
                t = rotateWithLeftChild( t );
            else
                t = doubleWithLeftChild( t );
        else
        if( height( t.right ) - height( t.left ) > ALLOWED_IMBALANCE )
            if( height( t.right.right ) >= height( t.right.left ) )
                t = rotateWithRightChild( t );
            else
                t = doubleWithRightChild( t );

        t.height = Math.max( height( t.left ), height( t.right ) ) + 1;
        return t;
    }
   
  
    private AVLNode rotateWithLeftChild(AVLNode k2)
    {
        AVLNode k1 = k2.left;
        k2.left = k1.right;
        k1.right = k2;
        k2.height = max( height( k2.left ), height( k2.right ) ) + 1;
        k1.height = max( height( k1.left ), k2.height ) + 1;
        return k1;
    }
    private AVLNode rotateWithRightChild(AVLNode k1)
    {
        AVLNode k2 = k1.right;
        k1.right = k2.left;
        k2.left = k1;
        k1.height = max( height( k1.left ), height( k1.right ) ) + 1;
        k2.height = max( height( k2.right ), k1.height ) + 1;
        return k2;
    }
    private AVLNode doubleWithLeftChild(AVLNode k3)
    {
        k3.left = rotateWithRightChild( k3.left );
        return rotateWithLeftChild( k3 );
    }
    private AVLNode doubleWithRightChild(AVLNode k1)
    {
        k1.right = rotateWithLeftChild( k1.right );
        return rotateWithRightChild( k1 );
    }    
    public int countNodes()
    {
        return countNodes(root);
    }
    private int countNodes(AVLNode r)
    {
        if (r == null)
            return 0;
        else
        {
            int l = 1;
            l += countNodes(r.left);
            l += countNodes(r.right);
            return l;
        }
    }
    public void inorder()
    {
        inorder(root);
    }
    private void inorder(AVLNode r)
    {
        if (r != null)
        {
            inorder(r.left);
            System.out.print(r.data +" ");
            inorder(r.right);
        }
    }
    public boolean search(int val)
    {
         return search(root, val);
    }
    private boolean search(AVLNode r, int val)
    {
        boolean found = false;
        while ((r != null) && !found)
        {
            Account rval = r.data;
            if (((Integer)val).compareTo(rval.getiD() )  < 0)
                r = r.left;
            else if (((Integer)val).compareTo(rval.getiD())> 0)
                r = r.right;
            else
            {
                found = true;
                break;
            }
            found = search(r, val);
        }
        return found ;
           }
}
class Account implements Comparable<Account>
{
	private  String accountHolderName;
	private int iD;
	public float balance; 
	public double total;
	public Account(int  a , String  n , float b)
	{
		iD= a;
		accountHolderName = n ;
		balance = b;;
	}	
	public Account()
	{

	}
	public int getiD()
	{
		return iD;
	}
	
	public String getaccountHolderName()
	{
		return accountHolderName;
	}
	public void   setBalance(float balance)
	{
		
		this.balance = balance; 
		total = total+balance;
		
	}
	public void totalAfterDelete(float b )
	{
		total = total - b ;
	}
	public double getTotal()
	{
		return total ;
	}
	
	public float getBalance()
	{
		return balance;
	}
	
		
	@Override
	public int compareTo(Account s1)
	{
		int differ;
		differ = ((Integer)this.getiD()).compareTo(s1.getiD());
		return differ;
	}
	
	@Override
	public String toString()
	{
		return iD+" "+accountHolderName+" "+balance;
	}
}

